force -freeze sim:/licznik/Clk 1 0, 0 {2500 ps} -r 5000
force -freeze sim:/licznik/nRESET 1 0
run 92400000
