onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /licznik/Clk
add wave -noupdate /licznik/nRESET
add wave -noupdate /licznik/LED
add wave -noupdate -radix decimal -radixshowbase 0 /licznik/AX
add wave -noupdate -radix decimal -radixshowbase 0 /licznik/BX
add wave -noupdate -radix decimal -radixshowbase 0 /licznik/CX
add wave -noupdate -radix decimal -radixshowbase 0 /licznik/DX
add wave -noupdate -radix decimal /licznik/FX
add wave -noupdate -radix decimal /licznik/EX
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {0 ps} 0}
quietly wave cursor active 0
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ps} {609 ps}
